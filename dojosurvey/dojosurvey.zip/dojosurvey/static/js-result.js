$(document).ready(function (){
    $(document).on ('click', 'button', function (){
        alert ('You clicked me')
    })
})